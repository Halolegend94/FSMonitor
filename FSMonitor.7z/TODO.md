##TODO:
    - Sviluppo protocollo di rete;
    - Fare la funzione di smaltimento notifiche e completare la struttura dati client register
