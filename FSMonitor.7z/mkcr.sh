gcc --static -g -o pro client_register.c client_path_tree.c client_node_list.c linux/myfile.c linux/cr_lock.c linked_list.c tests/client_register_test.c -pthread
